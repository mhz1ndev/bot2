#!/usr/bin/env python
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from app.models.ip_manager import IPManager

def main():
    IPManager.init_db()
    print("=" * 50)
    print("🔐 GERENCIADOR DE IPs")
    print("=" * 50)
    print("\n1 - Listar IPs")
    print("2 - Adicionar IP")
    print("3 - Remover IP")
    print("4 - Ver logs")
    
    opcao = input("\nOpção: ")
    
    if opcao == '1':
        for ip in IPManager.listar_ips():
            print(f"{ip['ip']} - {ip['descricao'] or '-'}")
    elif opcao == '2':
        ip = input("IP: ")
        desc = input("Descrição: ")
        IPManager.adicionar_ip(ip, desc)
        print("✅ Adicionado")
    elif opcao == '3':
        ip = input("IP: ")
        IPManager.remover_ip(ip)
        print("✅ Removido")
    elif opcao == '4':
        for log in IPManager.obter_logs(20):
            status = "✅" if log['autorizado'] else "❌"
            print(f"{log['data_acesso'][:19]} {status} {log['ip']} {log['endpoint']}")

if __name__ == '__main__':
    main()