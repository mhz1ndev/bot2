import os

class Config:
    """Configurações principais da aplicação"""
    
    # Diretório base
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # ==================== TODAS AS DATABASES ====================
    DATABASES = {
        # 1. Banco de dados principal
        'bigdata': os.path.join(r'F:\big_data', 'bigdata.db'),
        
        # 2. Vivo PR
        'vivo_pr': os.path.join(r'F:\big_data', 'vivo_pr.db'),
        
        # 3. Oi
        'oi': os.path.join(r'F:\big_data', 'OI_db.db'),
        
        # 4. Brazilian People
        'brazilian_people': os.path.join(r'F:\big_data', 'BrazilianPeople.db'),
        
        # 5. CADSUS (SUS)
        'cadsus': os.path.join(r'F:', 'cadsus.db'),
        
        # 6. CPF 15 Milhões
        'cpf15m': os.path.join(r'F:\big_data', 'cpf15M.db'),
        
        # 7. BR 180 Milhões (DataSUS)
        'br180m': os.path.join(r'F:\big_data', 'BR180M-datasus.db')
    }
    
    # Bancos de dados de controle
    TOKEN_DB_PATH = os.path.join(BASE_DIR, 'tokens.db')
    IP_DB_PATH = os.path.join(BASE_DIR, 'ips.db')
    
    # Timeouts
    IP_QUERY_TIMEOUT = 2.8
    DNS_TIMEOUT = 1.0
    HTTP_TIMEOUT = 1.0
    WHOIS_TIMEOUT = 1.0
    
    # Mapeamento de chaves para padronização
    KEY_MAP = {
        # DADOS
        'CONTATOS_ID': 'contatosId',
        'CPF': 'cpf',
        'NOME': 'nome',
        'SEXO': 'sexo',
        'NASC': 'dataNascimento',
        'NOME_MAE': 'nomeMae',
        'NOME_PAI': 'nomePai',
        'CADASTRO_ID': 'cadastroId',
        'ESTCIV': 'estadoCivil',
        'RG': 'rg',
        'NACIONALID': 'nacionalidade',
        'CONTATOS_ID_CONJUGE': 'contatosIdConjuge',
        'SO': 'sistemaOperacional',
        'CD_SIT_CAD': 'codigoSituacaoCadastral',
        'DT_SIT_CAD': 'dataSituacaoCadastral',
        'DT_INFORMACAO': 'dataInformacao',
        'CBO': 'cbo',
        'ORGAO_EMISSOR': 'orgaoEmissor',
        'UF_EMISSAO': 'ufEmissao',
        'DT_OB': 'dataObito',
        'CD_MOSAIC': 'codigoMosaic',
        'RENDA': 'renda',
        'FAIXA_RENDA_ID': 'faixaRendaId',
        'TITULO_ELEITOR': 'tituloEleitor',
        'CD_MOSAIC_NOVO': 'codigoMosaicNovo',
        'CD_MOSAIC_SECUNDARIO': 'codigoMosaicSecundario',
        
        # EMAIL
        'EMAIL': 'email',
        'PRIORIDADE': 'prioridade',
        'EMAIL_SCORE': 'emailScore',
        'EMAIL_PESSOAL': 'emailPessoal',
        'EMAIL_DUPLICADO': 'emailDuplicado',
        'BLACKLIST': 'blacklist',
        'ESTRUTURA': 'estrutura',
        'STATUS_VT': 'statusVt',
        'DOMINIO': 'dominio',
        'MAPAS': 'mapas',
        'PESO': 'peso',
        'DT_INCLUSAO': 'dataInclusao',
        
        # TELEFONE
        'DDD': 'ddd',
        'TELEFONE': 'telefone',
        'TIPO_TELEFONE': 'tipoTelefone',
        'SIGILO': 'sigilo',
        'NSU': 'nsu',
        'CLASSIFICACAO': 'classificacao',
        
        # ENDERECOS
        'LOGR_TIPO': 'logradouroTipo',
        'LOGR_NOME': 'logradouroNome',
        'LOGR_NUMERO': 'logradouroNumero',
        'LOGR_COMPLEMENTO': 'logradouroComplemento',
        'BAIRRO': 'bairro',
        'CIDADE': 'cidade',
        'UF': 'uf',
        'CEP': 'cep',
        'DT_ATUALIZACAO': 'dataAtualizacao',
        'TIPO_ENDERECO_ID': 'tipoEnderecoId',
        
        # PARENTES
        'CPF_Completo': 'cpfCompleto',
        'CPF_VINCULO': 'cpfVinculo',
        'NOME_VINCULO': 'nomeVinculo',
        'VINCULO': 'vinculo',
        
        # SCORE
        'CSB8': 'csb8',
        'CSB8_FAIXA': 'csb8Faixa',
        'CSBA': 'csba',
        'CSBA_FAIXA': 'csbaFaixa',
        
        # TSE
        'ZONA': 'zona',
        'SECAO': 'secao',
        
        # PIS
        'PIS': 'pis',
        
        # CAMPOS COMUNS
        'dt_nascimento': 'dataNascimento',
        'nm_mae': 'nomeMae',
        'nm_pai': 'nomePai',
        'nr_cpf': 'cpf',
        'nr_cns': 'cartaoNacionalSaude',
        'nm_municipio': 'municipio',
        'sg_uf': 'uf',
        'dt_atualizacao': 'dataAtualizacao',
        'telefone1': 'telefone',
        'telefone2': 'telefone2',
        'endereco': 'enderecoCompleto'
    }