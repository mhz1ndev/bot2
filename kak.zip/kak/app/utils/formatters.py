import unicodedata
from app.config import Config

class Formatters:
    
    @staticmethod
    def remover_acentos(texto):
        if not isinstance(texto, str):
            return texto
        nfkd_form = unicodedata.normalize('NFD', texto)
        return "".join([c for c in nfkd_form if not unicodedata.combining(c)])
    
    @staticmethod
    def formatar_resposta_json(data):
        if isinstance(data, dict):
            return {Config.KEY_MAP.get(k, k.lower()): Formatters.formatar_resposta_json(v) for k, v in data.items()}
        if isinstance(data, list):
            return [Formatters.formatar_resposta_json(item) for item in data]
        if isinstance(data, str):
            return Formatters.remover_acentos(data).strip()
        return data