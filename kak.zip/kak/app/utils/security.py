from functools import wraps
from flask import request, jsonify, g
from app.models.token_manager import TokenManager
from app.models.log_manager import LogManager
import time

def requer_token_url(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        start_time = time.time()
        token = kwargs.get('token')
        
        if not token:
            token = request.headers.get('Authorization')
            if token and token.startswith('Bearer '):
                token = token[7:]
        
        if not token:
            return jsonify({'status': 401, 'erro': 'Token não fornecido'}), 401
        
        valido, token_real, dados_token = TokenManager.validar_token(token)
        
        if not valido:
            return jsonify({'status': 401, 'erro': 'Token inválido'}), 401
        
        client_ip = request.headers.get('X-Forwarded-For', request.remote_addr).split(',')[0]
        tempo = time.time() - start_time
        
        LogManager.registrar_log(token_real, request.path, request.method, client_ip, request.headers.get('User-Agent'), 200, tempo)
        
        return f(*args, **kwargs)
    
    return decorated_function

def requer_token(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        start_time = time.time()
        token = request.headers.get('Authorization')
        
        if token and token.startswith('Bearer '):
            token = token[7:]
        
        if not token:
            token = request.args.get('token')
        
        if not token:
            return jsonify({'status': 401, 'erro': 'Token não fornecido'}), 401
        
        valido, token_real, dados_token = TokenManager.validar_token(token)
        
        if not valido:
            return jsonify({'status': 401, 'erro': 'Token inválido'}), 401
        
        client_ip = request.headers.get('X-Forwarded-For', request.remote_addr).split(',')[0]
        tempo = time.time() - start_time
        
        LogManager.registrar_log(token_real, request.path, request.method, client_ip, request.headers.get('User-Agent'), 200, tempo)
        
        return f(*args, **kwargs)
    
    return decorated_function