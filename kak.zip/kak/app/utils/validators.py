import re
import ipaddress

class Validators:
    
    @staticmethod
    def validar_cpf(cpf):
        cpf = re.sub(r'[^0-9]', '', str(cpf))
        if len(cpf) != 11 or cpf == cpf[0] * 11:
            return False
        soma = sum(int(cpf[i]) * (10 - i) for i in range(9))
        digito1 = (soma * 10 % 11) % 10
        if int(cpf[9]) != digito1:
            return False
        soma = sum(int(cpf[i]) * (11 - i) for i in range(10))
        digito2 = (soma * 10 % 11) % 10
        return int(cpf[10]) == digito2
    
    @staticmethod
    def validar_cnpj(cnpj):
        cnpj = re.sub(r'[^0-9]', '', str(cnpj))
        if len(cnpj) != 14:
            return False
        peso1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        soma = sum(int(cnpj[i]) * peso1[i] for i in range(12))
        digito1 = 0 if soma % 11 < 2 else 11 - (soma % 11)
        if int(cnpj[12]) != digito1:
            return False
        peso2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        soma = sum(int(cnpj[i]) * peso2[i] for i in range(13))
        digito2 = 0 if soma % 11 < 2 else 11 - (soma % 11)
        return int(cnpj[13]) == digito2
    
    @staticmethod
    def validar_ip(ip):
        try:
            ipaddress.ip_address(ip)
            return True
        except:
            return False
    
    @staticmethod
    def validar_telefone(telefone):
        telefone = re.sub(r'[^0-9]', '', str(telefone))
        return len(telefone) in [10, 11]
    
    @staticmethod
    def sanitizar_input(valor, max_len=255):
        if not valor:
            return None
        valor = str(valor).strip()
        if len(valor) > max_len:
            valor = valor[:max_len]
        return re.sub(r'[^\w\s@.-]', '', valor)
    
    @staticmethod
    def validar_nome(nome):
        if not nome or len(nome) < 3:
            return False
        return len(nome.strip()) > 0