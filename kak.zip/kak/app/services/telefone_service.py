from app.models.database_manager import DatabaseManager
from app.config import Config
from app.utils.formatters import Formatters

class TelefoneService:
    
    @staticmethod
    def consultar_completo(numero):
        """Consulta por telefone em todas as databases"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['bigdata'])
            cursor = conn.cursor()
            resultados = []
            
            # Limpar número
            numero_limpo = numero.replace('-', '').replace('(', '').replace(')', '').replace(' ', '')
            
            if len(numero_limpo) >= 10:
                ddd = numero_limpo[:2]
                telefone_numero = numero_limpo[2:]
                
                # Buscar com DDD
                cursor.execute("""
                    SELECT CONTATOS_ID, DDD, TELEFONE, TIPO_TELEFONE
                    FROM TELEFONE 
                    WHERE DDD = ? AND TELEFONE = ?
                """, (ddd, telefone_numero))
                telefones = cursor.fetchall()
                
                if not telefones:
                    cursor.execute("""
                        SELECT CONTATOS_ID, DDD, TELEFONE, TIPO_TELEFONE
                        FROM TELEFONE 
                        WHERE TELEFONE = ?
                    """, (numero_limpo,))
                    telefones = cursor.fetchall()
            else:
                cursor.execute("""
                    SELECT CONTATOS_ID, DDD, TELEFONE, TIPO_TELEFONE
                    FROM TELEFONE 
                    WHERE TELEFONE = ?
                """, (numero_limpo,))
                telefones = cursor.fetchall()
            
            if not telefones:
                return None
            
            for tel in telefones:
                cursor.execute("""
                    SELECT CPF, NOME
                    FROM DADOS
                    WHERE CONTATOS_ID = ?
                """, (tel['CONTATOS_ID'],))
                dados = cursor.fetchone()
                
                resultado = {
                    "contatos_id": tel['CONTATOS_ID'],
                    "ddd": tel['DDD'],
                    "telefone": tel['TELEFONE'],
                    "telefone_completo": f"({tel['DDD']}) {tel['TELEFONE']}",
                    "tipo_telefone": tel['TIPO_TELEFONE'],
                    "cpf": dados['CPF'] if dados else None,
                    "nome": dados['NOME'] if dados else None
                }
                resultados.append(resultado)
            
            return Formatters.formatar_resposta_json(resultados)
            
        except Exception as e:
            return {'erro': str(e)}