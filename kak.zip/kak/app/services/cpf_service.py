from concurrent.futures import ThreadPoolExecutor, as_completed
from app.models.database_manager import DatabaseManager
from app.config import Config
from app.utils.formatters import Formatters

class CPFService:
    
    @staticmethod
    def consultar_bigdata(cpf):
        """Consulta bigdata.db - Múltiplas tabelas"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['bigdata'])
            cursor = conn.cursor()
            
            # Tabela principal DADOS
            cursor.execute("SELECT * FROM DADOS WHERE CPF = ?", (cpf,))
            dados = cursor.fetchone()
            
            if not dados:
                return None
            
            dados_dict = dict(dados)
            contatos_id = dados_dict.get('CONTATOS_ID')
            
            # Função para consultar tabelas relacionadas
            def consultar_tabela(tabela, id_coluna='CONTATOS_ID', id_valor=contatos_id):
                try:
                    cursor.execute(f"SELECT * FROM {tabela} WHERE {id_coluna} = ?", (id_valor,))
                    return [dict(row) for row in cursor.fetchall()]
                except:
                    return []
            
            # Todas as tabelas do bigdata
            resultado = {
                'dadosPessoais': dados_dict,
                'emails': consultar_tabela('EMAIL'),
                'telefones': consultar_tabela('TELEFONE'),
                'enderecos': consultar_tabela('ENDERECOS'),
                'pis': consultar_tabela('PIS'),
                'score': consultar_tabela('SCORE'),
                'filiacaoTse': consultar_tabela('TSE'),
                'poderAquisitivo': consultar_tabela('PODER_AQUISITIVO'),
                'parentes': consultar_tabela('PARENTES', 'CPF_Completo', cpf)
            }
            
            return resultado
        except Exception as e:
            return {'erro': str(e)}
    
    @staticmethod
    def consultar_vivo_pr(cpf):
        """Consulta vivo_pr.db - Tabela vivo_pr_32M"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['vivo_pr'])
            cursor = conn.cursor()
            
            resultados = {}
            
            # Tabela principal
            try:
                cursor.execute("SELECT * FROM vivo_pr_32M WHERE cpf = ?", (cpf,))
                registros = cursor.fetchall()
                if registros:
                    resultados['vivo_pr_32M'] = [dict(row) for row in registros]
            except:
                pass
            
            # Outras possíveis tabelas
            tabelas = ['vivo_dados', 'vivo_contatos', 'vivo_enderecos', 'vivo_telefones']
            for tabela in tabelas:
                try:
                    cursor.execute(f"SELECT * FROM {tabela} WHERE cpf = ?", (cpf,))
                    registros = cursor.fetchall()
                    if registros:
                        resultados[tabela] = [dict(row) for row in registros]
                except:
                    pass
            
            return resultados if resultados else None
        except Exception as e:
            return {'erro': str(e)}
    
    @staticmethod
    def consultar_oi(cpf):
        """Consulta OI_db.db - Múltiplas tabelas"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['oi'])
            cursor = conn.cursor()
            
            resultados = {}
            
            # Tabelas do banco OI
            tabelas = ['Oi_estados', 'tim_db', 'oi_clientes', 'oi_telefones', 'oi_enderecos']
            
            for tabela in tabelas:
                try:
                    if tabela == 'tim_db':
                        cursor.execute(f"SELECT * FROM {tabela} WHERE DOC = ?", (cpf,))
                    else:
                        cursor.execute(f"SELECT * FROM {tabela} WHERE cpf = ?", (cpf,))
                    
                    registros = cursor.fetchall()
                    if registros:
                        resultados[tabela] = [dict(row) for row in registros]
                except:
                    pass
            
            return resultados if resultados else None
        except Exception as e:
            return {'erro': str(e)}
    
    @staticmethod
    def consultar_brazilian_people(cpf):
        """Consulta BrazilianPeople.db - Tabela pessoas"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['brazilian_people'])
            cursor = conn.cursor()
            
            resultados = {}
            
            # Tabela principal
            try:
                cursor.execute("SELECT * FROM pessoas WHERE cpf = ?", (cpf,))
                registros = cursor.fetchall()
                if registros:
                    resultados['pessoas'] = [dict(row) for row in registros]
            except:
                pass
            
            # Outras tabelas
            tabelas = ['enderecos', 'telefones', 'contatos', 'documentos']
            for tabela in tabelas:
                try:
                    cursor.execute(f"SELECT * FROM {tabela} WHERE cpf = ?", (cpf,))
                    registros = cursor.fetchall()
                    if registros:
                        resultados[tabela] = [dict(row) for row in registros]
                except:
                    pass
            
            return resultados if resultados else None
        except Exception as e:
            return {'erro': str(e)}
    
    @staticmethod
    def consultar_cadsus(cpf):
        """Consulta cadsus.db - TODAS as tabelas do SUS"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['cadsus'])
            cursor = conn.cursor()
            
            # Obter todas as tabelas do banco
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            todas_tabelas = cursor.fetchall()
            
            resultados = {}
            
            for tabela in todas_tabelas:
                nome_tabela = tabela[0]
                try:
                    # Tentar diferentes nomes de colunas para CPF
                    colunas_possiveis = ['cpf', 'CPF', 'nr_cpf', 'documento', 'doc', 'nr_documento']
                    
                    for coluna in colunas_possiveis:
                        try:
                            cursor.execute(f"SELECT * FROM {nome_tabela} WHERE {coluna} = ?", (cpf,))
                            registros = cursor.fetchall()
                            if registros:
                                resultados[nome_tabela] = [dict(row) for row in registros]
                                break
                        except:
                            continue
                except:
                    pass
            
            return resultados if resultados else None
        except Exception as e:
            return {'erro': str(e)}
    
    @staticmethod
    def consultar_cpf15m(cpf):
        """Consulta cpf15M.db - 15 milhões de CPFs"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['cpf15m'])
            cursor = conn.cursor()
            
            resultados = {}
            
            # Tabela principal
            try:
                cursor.execute("SELECT * FROM cpf15M WHERE cpf = ?", (cpf,))
                registros = cursor.fetchall()
                if registros:
                    resultados['cpf15M'] = [dict(row) for row in registros]
            except:
                pass
            
            # Outras possíveis tabelas
            tabelas = ['dados_completos', 'informacoes', 'contatos']
            for tabela in tabelas:
                try:
                    cursor.execute(f"SELECT * FROM {tabela} WHERE cpf = ?", (cpf,))
                    registros = cursor.fetchall()
                    if registros:
                        resultados[tabela] = [dict(row) for row in registros]
                except:
                    pass
            
            return resultados if resultados else None
        except Exception as e:
            return {'erro': str(e)}
    
    @staticmethod
    def consultar_br180m(cpf):
        """Consulta BR180M-datasus.db - DataSUS com 180 milhões"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['br180m'])
            cursor = conn.cursor()
            
            resultados = {}
            
            # Tabela principal
            try:
                cursor.execute("SELECT * FROM cadastros WHERE cpf = ?", (cpf,))
                registros = cursor.fetchall()
                if registros:
                    resultados['cadastros'] = [dict(row) for row in registros]
            except:
                pass
            
            # Outras tabelas do DataSUS
            tabelas = ['datasus', 'pacientes', 'atendimentos', 'internacoes', 'obitos']
            for tabela in tabelas:
                try:
                    cursor.execute(f"SELECT * FROM {tabela} WHERE cpf = ?", (cpf,))
                    registros = cursor.fetchall()
                    if registros:
                        resultados[tabela] = [dict(row) for row in registros]
                except:
                    pass
            
            return resultados if resultados else None
        except Exception as e:
            return {'erro': str(e)}
    
    @staticmethod
    def consultar_completo(cpf):
        """Consulta TODAS as 7 databases em paralelo"""
        
        # Lista completa de funções de consulta
        funcoes_consulta = [
            ('bigdata', CPFService.consultar_bigdata),
            ('vivo_pr', CPFService.consultar_vivo_pr),
            ('oi', CPFService.consultar_oi),
            ('brazilian_people', CPFService.consultar_brazilian_people),
            ('cadsus', CPFService.consultar_cadsus),
            ('cpf15m', CPFService.consultar_cpf15m),
            ('br180m', CPFService.consultar_br180m)
        ]
        
        resultados = {}
        
        # Executar consultas em paralelo
        with ThreadPoolExecutor(max_workers=7) as executor:
            future_to_db = {
                executor.submit(func, cpf): nome_db 
                for nome_db, func in funcoes_consulta
            }
            
            for future in as_completed(future_to_db):
                nome_db = future_to_db[future]
                try:
                    resultado = future.result()
                    if resultado and not (isinstance(resultado, dict) and 'erro' in resultado and len(resultado) == 1):
                        resultados[nome_db] = resultado
                except Exception as e:
                    resultados[nome_db] = {'erro': str(e)}
        
        # Formatar resposta
        return Formatters.formatar_resposta_json(resultados) if resultados else None