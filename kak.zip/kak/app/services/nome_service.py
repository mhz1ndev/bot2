from concurrent.futures import ThreadPoolExecutor, as_completed
from app.models.database_manager import DatabaseManager
from app.config import Config
from app.utils.formatters import Formatters

class NomeService:
    
    @staticmethod
    def consultar_bigdata(nome):
        """Consulta bigdata.db por nome"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['bigdata'])
            cursor = conn.cursor()
            
            resultados = {}
            
            # Tabela DADOS
            try:
                cursor.execute("SELECT * FROM DADOS WHERE NOME = ?", (nome,))
                registros = cursor.fetchall()
                if registros:
                    resultados['dados'] = [dict(row) for row in registros]
            except:
                pass
            
            return resultados if resultados else None
        except Exception as e:
            return {'erro': str(e)}
    
    @staticmethod
    def consultar_vivo_pr(nome):
        """Consulta vivo_pr.db por nome"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['vivo_pr'])
            cursor = conn.cursor()
            
            resultados = {}
            
            try:
                cursor.execute("SELECT * FROM vivo_pr_32M WHERE nome = ?", (nome,))
                registros = cursor.fetchall()
                if registros:
                    resultados['vivo_pr_32M'] = [dict(row) for row in registros]
            except:
                pass
            
            return resultados if resultados else None
        except Exception as e:
            return {'erro': str(e)}
    
    @staticmethod
    def consultar_oi(nome):
        """Consulta OI_db.db por nome"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['oi'])
            cursor = conn.cursor()
            
            resultados = {}
            
            tabelas = ['Oi_estados', 'tim_db']
            for tabela in tabelas:
                try:
                    if tabela == 'tim_db':
                        cursor.execute(f"SELECT * FROM {tabela} WHERE NOME = ?", (nome,))
                    else:
                        cursor.execute(f"SELECT * FROM {tabela} WHERE nome = ?", (nome,))
                    
                    registros = cursor.fetchall()
                    if registros:
                        resultados[tabela] = [dict(row) for row in registros]
                except:
                    pass
            
            return resultados if resultados else None
        except Exception as e:
            return {'erro': str(e)}
    
    @staticmethod
    def consultar_brazilian_people(nome):
        """Consulta BrazilianPeople.db por nome"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['brazilian_people'])
            cursor = conn.cursor()
            
            resultados = {}
            
            try:
                cursor.execute("SELECT * FROM pessoas WHERE nome = ?", (nome,))
                registros = cursor.fetchall()
                if registros:
                    resultados['pessoas'] = [dict(row) for row in registros]
            except:
                pass
            
            return resultados if resultados else None
        except Exception as e:
            return {'erro': str(e)}
    
    @staticmethod
    def consultar_cadsus(nome):
        """Consulta cadsus.db por nome - TODAS as tabelas"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['cadsus'])
            cursor = conn.cursor()
            
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            todas_tabelas = cursor.fetchall()
            
            resultados = {}
            
            for tabela in todas_tabelas:
                nome_tabela = tabela[0]
                try:
                    for coluna in ['nome', 'NOME', 'nm_pessoa', 'nm_cidadao']:
                        try:
                            cursor.execute(f"SELECT * FROM {nome_tabela} WHERE {coluna} = ?", (nome,))
                            registros = cursor.fetchall()
                            if registros:
                                resultados[nome_tabela] = [dict(row) for row in registros]
                                break
                        except:
                            continue
                except:
                    pass
            
            return resultados if resultados else None
        except Exception as e:
            return {'erro': str(e)}
    
    @staticmethod
    def consultar_cpf15m(nome):
        """Consulta cpf15M.db por nome"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['cpf15m'])
            cursor = conn.cursor()
            
            resultados = {}
            
            try:
                cursor.execute("SELECT * FROM cpf15M WHERE nome = ?", (nome,))
                registros = cursor.fetchall()
                if registros:
                    resultados['cpf15M'] = [dict(row) for row in registros]
            except:
                pass
            
            return resultados if resultados else None
        except Exception as e:
            return {'erro': str(e)}
    
    @staticmethod
    def consultar_br180m(nome):
        """Consulta BR180M-datasus.db por nome"""
        try:
            conn = DatabaseManager.get_connection(Config.DATABASES['br180m'])
            cursor = conn.cursor()
            
            resultados = {}
            
            try:
                cursor.execute("SELECT * FROM cadastros WHERE nome = ?", (nome,))
                registros = cursor.fetchall()
                if registros:
                    resultados['cadastros'] = [dict(row) for row in registros]
            except:
                pass
            
            return resultados if resultados else None
        except Exception as e:
            return {'erro': str(e)}
    
    @staticmethod
    def consultar_completo(nome):
        """Consulta TODAS as 7 databases por nome"""
        nome_normalizado = Formatters.remover_acentos(nome.upper())
        
        funcoes_consulta = [
            ('bigdata', NomeService.consultar_bigdata),
            ('vivo_pr', NomeService.consultar_vivo_pr),
            ('oi', NomeService.consultar_oi),
            ('brazilian_people', NomeService.consultar_brazilian_people),
            ('cadsus', NomeService.consultar_cadsus),
            ('cpf15m', NomeService.consultar_cpf15m),
            ('br180m', NomeService.consultar_br180m)
        ]
        
        resultados = {}
        
        with ThreadPoolExecutor(max_workers=7) as executor:
            future_to_db = {
                executor.submit(func, nome_normalizado): nome_db 
                for nome_db, func in funcoes_consulta
            }
            
            for future in as_completed(future_to_db):
                nome_db = future_to_db[future]
                try:
                    resultado = future.result()
                    if resultado:
                        resultados[nome_db] = resultado
                except Exception as e:
                    resultados[nome_db] = {'erro': str(e)}
        
        return Formatters.formatar_resposta_json(resultados) if resultados else None