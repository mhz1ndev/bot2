from app.services.ip_service import IPService
from app.services.cpf_service import CPFService
from app.services.nome_service import NomeService
from app.services.telefone_service import TelefoneService
from app.services.cnpj_service import CNPJService

__all__ = ['IPService', 'CPFService', 'NomeService', 'TelefoneService', 'CNPJService']