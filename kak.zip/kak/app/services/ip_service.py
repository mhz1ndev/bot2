import socket
import requests
import time
from concurrent.futures import ThreadPoolExecutor
from app.config import Config

class IPService:
    
    @staticmethod
    def consulta_geolocalizacao(ip):
        try:
            url = f"http://ip-api.com/json/{ip}"
            response = requests.get(url, timeout=Config.HTTP_TIMEOUT)
            if response.status_code == 200:
                data = response.json()
                if data.get('status') == 'success':
                    return {
                        'ip': data.get('query'),
                        'pais': data.get('country'),
                        'cidade': data.get('city'),
                        'latitude': data.get('lat'),
                        'longitude': data.get('lon'),
                        'isp': data.get('isp')
                    }
        except:
            pass
        return None
    
    @staticmethod
    def consulta_dns_reverso(ip):
        try:
            hostname, _, _ = socket.gethostbyaddr(ip)
            return {'hostname': hostname}
        except:
            return {'hostname': 'nao_encontrado'}
    
    @staticmethod
    def consulta_completa(ip):
        start_time = time.time()
        
        geo = IPService.consulta_geolocalizacao(ip)
        dns = IPService.consulta_dns_reverso(ip)
        
        return {
            'geolocalizacao': geo,
            'dns_reverso': dns,
            'metadados': {
                'ip_consultado': ip,
                'tempo_processamento': f"{time.time() - start_time:.3f}s"
            }
        }