import requests

class CNPJService:
    
    @staticmethod
    def consultar_cnpj(cnpj):
        try:
            url = f"https://open.cnpja.com/office/{cnpj}"
            headers = {'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json'}
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code == 200:
                return response.json()
            return None
        except Exception as e:
            return {'erro': str(e)}