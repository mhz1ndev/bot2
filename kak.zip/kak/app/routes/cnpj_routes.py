from flask import Blueprint, jsonify
from app.utils.validators import Validators
from app.utils.security import requer_token_url
from app.middleware.ip_auth import requer_ip_autorizado
from app.services.cnpj_service import CNPJService
from datetime import datetime
import time

bp = Blueprint('cnpj', __name__, url_prefix='/v1')

@bp.route('/cnpj/<string:cnpj>/<string:token>', methods=['GET'])
@requer_ip_autorizado
@requer_token_url
def consulta_cnpj(cnpj, token, **kwargs):
    start_time = time.time()
    
    if not Validators.validar_cnpj(cnpj):
        return jsonify({"status": 400, "erro": "CNPJ inválido", "tempo": f"{(time.time() - start_time):.3f}s"}), 400
    
    try:
        resultado = CNPJService.consultar_cnpj(cnpj)
        if not resultado:
            return jsonify({"status": 404, "erro": "CNPJ não encontrado", "tempo": f"{(time.time() - start_time):.3f}s"}), 404
        return jsonify({"status": 200, "cnpj": cnpj, "tempo": f"{time.time() - start_time:.3f}s", "dados": resultado}), 200
    except Exception as e:
        return jsonify({"status": 500, "erro": str(e), "tempo": f"{(time.time() - start_time):.3f}s"}), 500