from flask import Blueprint, jsonify
from app.utils.validators import Validators
from app.utils.security import requer_token_url
from app.middleware.ip_auth import requer_ip_autorizado
from app.services.cpf_service import CPFService
from datetime import datetime
import time

bp = Blueprint('cpf', __name__, url_prefix='/v1')

@bp.route('/cpf/<string:cpf>/<string:token>', methods=['GET'])
@requer_ip_autorizado
@requer_token_url
def consulta_cpf(cpf, token, **kwargs):
    start_time = time.time()
    
    if not Validators.validar_cpf(cpf):
        return jsonify({'status': 400, 'erro': 'CPF inválido', 'tempo': f"{(time.time() - start_time):.3f}s"}), 400
    
    try:
        resultados = CPFService.consultar_completo(cpf)
        if not resultados:
            return jsonify({'status': 404, 'erro': 'Não encontrado', 'tempo': f"{(time.time() - start_time):.3f}s"}), 404
        return jsonify({'status': 200, 'cpf': cpf, 'tempo': f"{(time.time() - start_time):.3f}s", 'data': resultados}), 200
    except Exception as e:
        return jsonify({'status': 500, 'erro': str(e), 'tempo': f"{(time.time() - start_time):.3f}s"}), 500