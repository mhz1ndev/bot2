from flask import Blueprint, jsonify
from app.utils.validators import Validators
from app.utils.security import requer_token_url
from app.middleware.ip_auth import requer_ip_autorizado
from app.services.nome_service import NomeService
from datetime import datetime
import time

bp = Blueprint('nome', __name__, url_prefix='/v1')

@bp.route('/nome/<string:nome>/<string:token>', methods=['GET'])
@requer_ip_autorizado
@requer_token_url
def consulta_nome(nome, token, **kwargs):
    start_time = time.time()
    
    nome = Validators.sanitizar_input(nome)
    if not nome:
        return jsonify({'status': 400, 'erro': 'Nome inválido', 'tempo': f"{(time.time() - start_time):.3f}s"}), 400
    
    try:
        resultados = NomeService.consultar_completo(nome)
        if not resultados:
            return jsonify({'status': 404, 'erro': 'Não encontrado', 'tempo': f"{(time.time() - start_time):.3f}s"}), 404
        return jsonify({'status': 200, 'nome': nome, 'tempo': f"{(time.time() - start_time):.3f}s", 'data': resultados}), 200
    except Exception as e:
        return jsonify({'status': 500, 'erro': str(e), 'tempo': f"{(time.time() - start_time):.3f}s"}), 500