from flask import Blueprint, jsonify
from app.utils.validators import Validators
from app.utils.security import requer_token_url
from app.middleware.ip_auth import requer_ip_autorizado
from app.services.telefone_service import TelefoneService
from datetime import datetime
import time

bp = Blueprint('telefone', __name__, url_prefix='/v1')

@bp.route('/telefone/<string:numero>/<string:token>', methods=['GET'])
@requer_ip_autorizado
@requer_token_url
def consulta_telefone(numero, token, **kwargs):
    start_time = time.time()
    
    if not Validators.validar_telefone(numero):
        return jsonify({"status": 400, "erro": "Telefone inválido", "tempo": f"{(time.time() - start_time):.3f}s"}), 400
    
    try:
        resultados = TelefoneService.consultar_completo(numero)
        return jsonify({"status": 200, "telefone": numero, "tempo": f"{(time.time() - start_time):.3f}s", "resultados": resultados or []}), 200
    except Exception as e:
        return jsonify({"status": 500, "erro": str(e), "tempo": f"{(time.time() - start_time):.3f}s"}), 500

@bp.route('/telefone/<string:ddd>/<string:numero>/<string:token>', methods=['GET'])
@requer_ip_autorizado
@requer_token_url
def consulta_telefone_ddd(ddd, numero, token, **kwargs):
    return consulta_telefone(ddd + numero, token, **kwargs)