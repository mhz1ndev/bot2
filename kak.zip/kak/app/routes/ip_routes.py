from flask import Blueprint, jsonify
from app.utils.validators import Validators
from app.utils.security import requer_token_url
from app.middleware.ip_auth import requer_ip_autorizado
from app.services.ip_service import IPService
from datetime import datetime
import time

bp = Blueprint('ip', __name__, url_prefix='/v1')

@bp.route('/ip/<string:endereco_ip>/<string:token>', methods=['GET'])
@requer_ip_autorizado
@requer_token_url
def consulta_ip(endereco_ip, token, **kwargs):
    start_time = time.time()
    
    if not Validators.validar_ip(endereco_ip):
        return jsonify({"status": 400, "erro": "IP inválido", "tempo_resposta": f"{(time.time() - start_time):.3f}s"}), 400
    
    try:
        resultados = IPService.consulta_completa(endereco_ip)
        return jsonify({"status": 200, "ip": endereco_ip, "tempo": f"{time.time() - start_time:.3f}s", "dados": resultados}), 200
    except Exception as e:
        return jsonify({"status": 500, "erro": str(e), "tempo": f"{time.time() - start_time:.3f}s"}), 500