from app.routes import ip_routes, cpf_routes, nome_routes, telefone_routes, cnpj_routes

__all__ = ['ip_routes', 'cpf_routes', 'nome_routes', 'telefone_routes', 'cnpj_routes']