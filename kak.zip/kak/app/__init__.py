from flask import Flask, render_template, request
from flask_cors import CORS
import os

def create_app():
    """Cria e configura a aplicação Flask"""
    app = Flask(__name__, 
                template_folder='../templates',
                static_folder='../static')
    
    # Configurações
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'sua-chave-secreta-aqui')
    app.config['JSON_AS_ASCII'] = False
    app.config['JSON_SORT_KEYS'] = False
    
    # Habilitar CORS
    CORS(app, resources={
        r"/*": {
            "origins": "*",
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization"]
        }
    })
    
    # Importar após criar app para evitar circular import
    from app.models.ip_manager import IPManager
    
    # Registrar blueprints
    from app.routes import ip_routes, cpf_routes, nome_routes, telefone_routes, cnpj_routes
    
    app.register_blueprint(ip_routes.bp)
    app.register_blueprint(cpf_routes.bp)
    app.register_blueprint(nome_routes.bp)
    app.register_blueprint(telefone_routes.bp)
    app.register_blueprint(cnpj_routes.bp)
    
    # Rota principal
    @app.route('/')
    def index():
        client_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
        if client_ip:
            client_ip = client_ip.split(',')[0].strip()
        print(client_ip)
        if IPManager.verificar_ip(client_ip):
            return render_template('index.html')
        else:
            return render_template('acesso_negado.html', ip=client_ip), 403
    
    # Página de acesso negado
    @app.route('/acesso-negado')
    def acesso_negado_view():
        client_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
        if client_ip:
            client_ip = client_ip.split(',')[0].strip()
            print(client_ip)
        return render_template('acesso_negado.html', ip=client_ip), 403
    
    # Health check
    @app.route('/health')
    def health_check():
        client_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
        if client_ip:
            client_ip = client_ip.split(',')[0].strip()
        
        if IPManager.verificar_ip(client_ip):
            return {
                'status': 'ok',
                'versao': '2.0.0',
                'timestamp': __import__('datetime').datetime.now().isoformat()
            }
        else:
            return {'status': 'acesso_negado'}, 403
    
    return app