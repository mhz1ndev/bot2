import sqlite3
from datetime import datetime
from app.config import Config

class LogManager:
    """Gerenciador de logs"""
    
    @staticmethod
    def registrar_log(token, endpoint, metodo, ip, user_agent, status_code, tempo_resposta):
        try:
            conn = sqlite3.connect(Config.TOKEN_DB_PATH)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO logs_acesso (token, endpoint, metodo, ip, user_agent, status_code, tempo_resposta)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (token, endpoint, metodo, ip, user_agent[:200] if user_agent else None, status_code, tempo_resposta))
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"Erro ao registrar log: {e}")
    
    @staticmethod
    def log_terminal(ip, endpoint, metodo, status_code, tempo_resposta, user_agent=None, token=None):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        token_info = f" | Token: {token[:16]}..." if token else ""
        print(f"[{timestamp}] | {metodo} {endpoint} | Status: {status_code} | Tempo: {tempo_resposta:.3f}s | IP: {ip}{token_info}")
    
    @staticmethod
    def limpar_logs_antigos(dias=30):
        conn = sqlite3.connect(Config.TOKEN_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM logs_acesso WHERE data_acesso < datetime('now', ?)", (f'-{dias} days',))
        conn.commit()
        conn.close()