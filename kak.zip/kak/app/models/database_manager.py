import sqlite3
import threading

thread_local = threading.local()

class DatabaseManager:
    """Gerenciador de conexões com banco de dados"""
    
    @staticmethod
    def get_connection(db_path):
        if not hasattr(thread_local, 'connections'):
            thread_local.connections = {}
        
        if db_path not in thread_local.connections:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA journal_mode=WAL")
            thread_local.connections[db_path] = conn
        
        return thread_local.connections[db_path]
    
    @staticmethod
    def close_connections():
        if hasattr(thread_local, 'connections'):
            for conn in thread_local.connections.values():
                conn.close()
            thread_local.connections = {}