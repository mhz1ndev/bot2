import sqlite3
import secrets
from datetime import datetime
from app.config import Config

class TokenManager:
    """Gerenciador de tokens de autenticação"""
    
    @staticmethod
    def init_db():
        """Inicializa o banco de dados de tokens"""
        conn = sqlite3.connect(Config.TOKEN_DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tokens (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                token TEXT UNIQUE NOT NULL,
                nome TEXT NOT NULL,
                descricao TEXT,
                criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                ultimo_uso TIMESTAMP,
                expira_em TIMESTAMP,
                ativo BOOLEAN DEFAULT 1,
                permissoes TEXT DEFAULT 'consulta',
                limite_requisicoes INTEGER DEFAULT NULL,
                requisicoes_feitas INTEGER DEFAULT 0
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS logs_acesso (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                token TEXT,
                endpoint TEXT,
                metodo TEXT,
                ip TEXT,
                user_agent TEXT,
                status_code INTEGER,
                tempo_resposta REAL,
                data_acesso TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_token ON tokens(token)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_logs_token ON logs_acesso(token)')
        
        conn.commit()
        conn.close()
    
    @staticmethod
    def gerar_token():
        return secrets.token_urlsafe(32)
    
    @staticmethod
    def criar_token(nome, descricao=None, expira_em=None, permissoes='consulta', limite_requisicoes=None):
        conn = sqlite3.connect(Config.TOKEN_DB_PATH)
        cursor = conn.cursor()
        token = TokenManager.gerar_token()
        
        try:
            cursor.execute('''
                INSERT INTO tokens (token, nome, descricao, expira_em, permissoes, limite_requisicoes)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (token, nome, descricao, expira_em, permissoes, limite_requisicoes))
            conn.commit()
            return token
        except sqlite3.IntegrityError:
            return TokenManager.criar_token(nome, descricao, expira_em, permissoes, limite_requisicoes)
        finally:
            conn.close()
    
    @staticmethod
    def validar_token(token):
        if not token:
            return False, None, None
        
        conn = sqlite3.connect(Config.TOKEN_DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT nome, descricao, permissoes, ativo, expira_em, limite_requisicoes, requisicoes_feitas
            FROM tokens WHERE token = ?
        ''', (token,))
        resultado = cursor.fetchone()
        
        if not resultado:
            conn.close()
            return False, None, None
        
        nome, descricao, permissoes, ativo, expira_em, limite_requisicoes, requisicoes_feitas = resultado
        
        if ativo != 1:
            conn.close()
            return False, None, None
        
        if expira_em:
            expira_date = datetime.fromisoformat(expira_em)
            if datetime.now() > expira_date:
                conn.close()
                return False, None, None
        
        if limite_requisicoes and requisicoes_feitas >= limite_requisicoes:
            conn.close()
            return False, None, None
        
        cursor.execute('''
            UPDATE tokens SET ultimo_uso = CURRENT_TIMESTAMP, requisicoes_feitas = requisicoes_feitas + 1
            WHERE token = ?
        ''', (token,))
        conn.commit()
        conn.close()
        
        return True, token, {'nome': nome, 'descricao': descricao, 'permissoes': permissoes}
    
    @staticmethod
    def listar_tokens():
        conn = sqlite3.connect(Config.TOKEN_DB_PATH)
        cursor = conn.cursor()
        cursor.execute('SELECT token, nome, descricao, criado_em, ultimo_uso, expira_em, ativo, permissoes, limite_requisicoes, requisicoes_feitas FROM tokens ORDER BY criado_em DESC')
        resultados = cursor.fetchall()
        conn.close()
        
        return [{'token': r[0], 'nome': r[1], 'descricao': r[2], 'criado_em': r[3], 'ultimo_uso': r[4], 'expira_em': r[5], 'ativo': bool(r[6]), 'permissoes': r[7], 'limite_requisicoes': r[8], 'requisicoes_feitas': r[9]} for r in resultados]
    
    @staticmethod
    def revogar_token(token):
        conn = sqlite3.connect(Config.TOKEN_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("UPDATE tokens SET ativo = 0 WHERE token = ?", (token,))
        conn.commit()
        conn.close()
        return True
    
    @staticmethod
    def deletar_token(token):
        conn = sqlite3.connect(Config.TOKEN_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM logs_acesso WHERE token = ?", (token,))
        cursor.execute("DELETE FROM tokens WHERE token = ?", (token,))
        conn.commit()
        conn.close()
        return True