import sqlite3
from app.config import Config

class IPManager:
    """Gerenciador de IPs autorizados"""
    
    @staticmethod
    def init_db():
        conn = sqlite3.connect(Config.IP_DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS ips_autorizados (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ip TEXT NOT NULL,
                descricao TEXT,
                criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                ultimo_acesso TIMESTAMP,
                ativo BOOLEAN DEFAULT 1,
                UNIQUE(ip)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS logs_ips (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ip TEXT NOT NULL,
                endpoint TEXT,
                metodo TEXT,
                autorizado BOOLEAN,
                user_agent TEXT,
                status_code INTEGER,
                tempo_resposta REAL,
                data_acesso TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_ip ON ips_autorizados(ip)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_logs_ip ON logs_ips(ip)')
        
        ips_padrao = [('127.0.0.1', 'Localhost'), ('::1', 'Localhost IPv6')]
        for ip, desc in ips_padrao:
            cursor.execute("INSERT OR IGNORE INTO ips_autorizados (ip, descricao) VALUES (?, ?)", (ip, desc))
        
        conn.commit()
        conn.close()
    
    @staticmethod
    def adicionar_ip(ip, descricao=None):
        try:
            conn = sqlite3.connect(Config.IP_DB_PATH)
            cursor = conn.cursor()
            cursor.execute("INSERT INTO ips_autorizados (ip, descricao) VALUES (?, ?)", (ip, descricao))
            conn.commit()
            conn.close()
            return True
        except sqlite3.IntegrityError:
            return False
    
    @staticmethod
    def remover_ip(ip):
        conn = sqlite3.connect(Config.IP_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM ips_autorizados WHERE ip = ?", (ip,))
        conn.commit()
        conn.close()
        return True
    
    @staticmethod
    def listar_ips():
        conn = sqlite3.connect(Config.IP_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT ip, descricao, criado_em, ultimo_acesso, ativo FROM ips_autorizados ORDER BY criado_em DESC")
        resultados = cursor.fetchall()
        conn.close()
        return [{'ip': r[0], 'descricao': r[1], 'criado_em': r[2], 'ultimo_acesso': r[3], 'ativo': bool(r[4])} for r in resultados]
    
    @staticmethod
    def verificar_ip(ip):
        if ip.startswith(('127.', '::1')):
            return True
        
        conn = sqlite3.connect(Config.IP_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM ips_autorizados WHERE ip = ? AND ativo = 1", (ip,))
        resultado = cursor.fetchone()
        
        if resultado:
            cursor.execute("UPDATE ips_autorizados SET ultimo_acesso = CURRENT_TIMESTAMP WHERE ip = ?", (ip,))
            conn.commit()
            conn.close()
            return True
        
        conn.close()
        return False
    
    @staticmethod
    def registrar_tentativa(ip, endpoint, metodo, autorizado, user_agent=None, status_code=200, tempo_resposta=0):
        try:
            conn = sqlite3.connect(Config.IP_DB_PATH)
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO logs_ips (ip, endpoint, metodo, autorizado, user_agent, status_code, tempo_resposta) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (ip, endpoint, metodo, 1 if autorizado else 0, user_agent[:200] if user_agent else None, status_code, tempo_resposta)
            )
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"Erro ao registrar tentativa: {e}")
    
    @staticmethod
    def obter_logs(limite=100, apenas_negados=False):
        conn = sqlite3.connect(Config.IP_DB_PATH)
        cursor = conn.cursor()
        
        if apenas_negados:
            cursor.execute("SELECT ip, endpoint, metodo, autorizado, user_agent, status_code, data_acesso FROM logs_ips WHERE autorizado = 0 ORDER BY data_acesso DESC LIMIT ?", (limite,))
        else:
            cursor.execute("SELECT ip, endpoint, metodo, autorizado, user_agent, status_code, data_acesso FROM logs_ips ORDER BY data_acesso DESC LIMIT ?", (limite,))
        
        resultados = cursor.fetchall()
        conn.close()
        return [{'ip': r[0], 'endpoint': r[1], 'metodo': r[2], 'autorizado': bool(r[3]), 'user_agent': r[4], 'status_code': r[5], 'data_acesso': r[6]} for r in resultados]
    
    @staticmethod
    def obter_estatisticas():
        conn = sqlite3.connect(Config.IP_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM logs_ips")
        total = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM logs_ips WHERE autorizado = 1")
        autorizados = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM logs_ips WHERE autorizado = 0")
        negados = cursor.fetchone()[0]
        cursor.execute("SELECT ip, COUNT(*) as total FROM logs_ips GROUP BY ip ORDER BY total DESC LIMIT 10")
        top_ips = cursor.fetchall()
        conn.close()
        return {'total_tentativas': total, 'acessos_autorizados': autorizados, 'acessos_negados': negados, 'top_ips': [{'ip': ip[0], 'total': ip[1]} for ip in top_ips]}
    
    @staticmethod
    def limpar_logs_antigos(dias=30):
        try:
            conn = sqlite3.connect(Config.IP_DB_PATH)
            cursor = conn.cursor()
            cursor.execute("DELETE FROM logs_ips WHERE data_acesso < datetime('now', ?)", (f'-{dias} days',))
            conn.commit()
            conn.close()
            return True
        except:
            return False