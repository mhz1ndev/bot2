from functools import wraps
from flask import request, render_template, jsonify
from app.models.ip_manager import IPManager
from datetime import datetime

def requer_ip_autorizado(f):
    """Decorator para verificar se o IP está autorizado"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        client_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
        if client_ip:
            client_ip = client_ip.split(',')[0].strip()
        
        user_agent = request.headers.get('User-Agent', 'Desconhecido')
        metodo = request.method
        endpoint = request.path
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        if IPManager.verificar_ip(client_ip):
            IPManager.registrar_tentativa(client_ip, endpoint, metodo, True, user_agent)
            
            print(f"\n{'='*70}")
            print(f"✅ ACESSO AUTORIZADO | IP: {client_ip} | Rota: {endpoint}")
            print(f"🕒 {timestamp} | UA: {user_agent[:50]}...")
            print(f"{'='*70}\n")
            
            return f(*args, **kwargs)
        else:
            IPManager.registrar_tentativa(client_ip, endpoint, metodo, False, user_agent)
            
            print(f"\n{'='*70}")
            print(f"❌ ACESSO NEGADO | IP: {client_ip} | Rota: {endpoint}")
            print(f"🕒 {timestamp} | UA: {user_agent[:50]}...")
            print(f"{'='*70}\n")
            
            if request.path.startswith('/v1/'):
                return jsonify({
                    'status': 403,
                    'erro': 'IP não autorizado',
                    'ip': client_ip
                }), 403
            else:
                return render_template('acesso_negado.html', ip=client_ip), 403
    
    return decorated_function

def verificar_ip_rota(f):
    """Versão para rotas que não são API"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        client_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
        if client_ip:
            client_ip = client_ip.split(',')[0].strip()
        
        if IPManager.verificar_ip(client_ip):
            return f(*args, **kwargs)
        else:
            return render_template('acesso_negado.html', ip=client_ip), 403
    
    return decorated_function