#!/usr/bin/env python
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from app.models.token_manager import TokenManager

def main():
    TokenManager.init_db()
    print("=" * 50)
    print("🔐 GERENCIADOR DE TOKENS")
    print("=" * 50)
    print("\n1 - Criar token")
    print("2 - Listar tokens")
    print("3 - Revogar token")
    print("4 - Deletar token")
    
    opcao = input("\nOpção: ")
    
    if opcao == '1':
        nome = input("Nome: ")
        token = TokenManager.criar_token(nome)
        print(f"\n✅ Token: {token}")
    elif opcao == '2':
        for t in TokenManager.listar_tokens():
            print(f"{t['token'][:20]}... | {t['nome']} | {'✅' if t['ativo'] else '❌'}")
    elif opcao == '3':
        token = input("Token: ")
        TokenManager.revogar_token(token)
        print("✅ Revogado")
    elif opcao == '4':
        token = input("Token: ")
        TokenManager.deletar_token(token)
        print("✅ Deletado")

if __name__ == '__main__':
    main()