from app import create_app
from app.models.token_manager import TokenManager
from app.models.log_manager import LogManager
from app.models.ip_manager import IPManager

app = create_app()

if __name__ == '__main__':
    TokenManager.init_db()
    IPManager.init_db()
    LogManager.limpar_logs_antigos(30)
    IPManager.limpar_logs_antigos(30)
    
    print("=" * 70)
    print("🚀 DATAHUB API - SISTEMA COMPLETO")
    print("=" * 70)
    print("\n🔑 FORMATO: /v1/recurso/valor/TOKEN")
    print("   GET /v1/ip/8.8.8.8/SEU_TOKEN")
    print("   GET /v1/cpf/22791392866/SEU_TOKEN")
    print("   GET /v1/nome/Joao%20Silva/SEU_TOKEN")
    print("   GET /v1/telefone/11999999999/SEU_TOKEN")
    print("   GET /v1/cnpj/12345678000195/SEU_TOKEN")
    print("\n📋 GERENCIAR IPs: python manage_ips.py")
    print("📋 GERENCIAR TOKENS: python manage_tokens.py")
    print("\n✅ API INICIADA: http://localhost:4536")
    print("=" * 70)
    
    app.run(host='0.0.0.0', port=4536, debug=True, threaded=True)